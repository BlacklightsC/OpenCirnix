# /*
#  *  Ӣ�����Լ��
#  *
#  *  By actboy168
#  *
#  */
#
#ifndef INCLUDE_BJ_OPTIMIZATION_HERO_STAT_CHECK_H
#define INCLUDE_BJ_OPTIMIZATION_HERO_STAT_CHECK_H
#
# define HERO_STAT_CHECK_bj_HEROSTAT_STR 0  
# define HERO_STAT_CHECK_bj_HEROSTAT_AGI 1  
# define HERO_STAT_CHECK_bj_HEROSTAT_INT 2 
#
#endif
