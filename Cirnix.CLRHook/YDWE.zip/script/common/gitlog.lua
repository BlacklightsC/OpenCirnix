return {
    commit = '595c33a8056e6b304f69d479768f06c1bf12395d',
    date = 'Tue May 12 13:36:26 2020 +0800',
}